﻿using AdvancedEshop.Infrastructure;
using AdvancedEshop.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewComponents;

namespace AdvancedEshop.Components
{
    public class CartWidget:ViewComponent
    {
        public IViewComponentResult Invoke()
        {

        return View(HttpContext.Session.GetJson<Cart>("cart"));
        }
    }
}
